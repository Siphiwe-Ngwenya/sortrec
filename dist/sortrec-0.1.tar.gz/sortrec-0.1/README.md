## Building this package locally
'python setup.py sdist'
##Installing this package from GitHub
'pip install git+https://github.com/Siphiwe-Ngwenya/sortrec.git'
## updating this package from GitHub
'pip install --upgrade git+https://github.com/Siphiwe-Ngwenya/sortrec.git'

                        __Purpose For Building Package__
## Python package is built as a demonstration of my coding ability and to help with a
## quick way to run these calculations when needed.
                        __Function Types__
##This python package consists of two files, one that perform sorting loops and a file that performs
##recursive calculations.

                        __Functions Contained in Recursion__
sum_array(): This function will take numbers inside of an array and return the some of
all the elements inside the array.
fibonacci(): This function returns the sum of the nth number in a fibonacci sequence
factorial(): This function returns the product of the number n multiplied by all the numbers that precede n.
reverse(): This function takes a string and then prints it in reverse.

                      __Functions Contained in Sorting__
quick_sort():This function will sort an array in ascending order
bubble_sort():This function returns a sorted array in ascending order
merge_sort(): This function will sort an array in ascending order around a pivot point
